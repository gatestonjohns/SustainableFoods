package com.example.ecofood.appbody.preference;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RatingBar;

import com.example.ecofood.DisplayProductsActivity;
import com.example.ecofood.R;
import com.example.ecofood.utils.LocalStorage;

public class ThirdPreferencesActivity extends AppCompatActivity{

    private RatingBar Sustainability, Emissions, WaterUse, LandUse, Affordableness, Nutrition, Protein, Carbs, Fat;
    LinearLayout button_save;
    private int SustainabilityUserRating = 0, EmissionsUserRating = 0, WaterUseUserRating = 0, LandUseUserRating = 0, AffordablenessUserRating = 0, NutritionUserRating = 0, ProteinUserRating = 0, CarbsUserRating = 0, FatUserRating = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preference_child_two);

        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_envfair);
        //setSupportActionBar(toolbar);

        Sustainability = findViewById(R.id.SustainabilityRatingbar);
        Emissions = findViewById(R.id.EmissionsRatingbar);
        WaterUse = findViewById(R.id.WaterUseRatingbar);
        LandUse = findViewById(R.id.LandUseRatingbar);
        Affordableness = findViewById(R.id.AffordablenessRatingbar);
        Nutrition = findViewById(R.id.NutritionRatingbar);
        Protein = findViewById(R.id.ProteinRatingbar);
        Carbs = findViewById(R.id.CarbsRatingbar);
        Fat = findViewById(R.id.FatRatingbar);
        button_save = findViewById(R.id.SaveButton);

        Sustainability.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                SustainabilityUserRating = Math.round(rating);
            }
        });

        Emissions.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                EmissionsUserRating = Math.round(rating);
            }
        });

        WaterUse.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                WaterUseUserRating = Math.round(rating);
            }
        });

        LandUse.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                LandUseUserRating = Math.round(rating);
            }
        });

        Affordableness.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                AffordablenessUserRating = Math.round(rating);
            }
        });

        Nutrition.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                NutritionUserRating = Math.round(rating);
            }
        });

        Protein.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                ProteinUserRating = Math.round(rating);
            }
        });

        Carbs.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                CarbsUserRating = Math.round(rating);
            }
        });

        Fat.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                FatUserRating = Math.round(rating);
            }
        });

        button_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userId = LocalStorage.getLocallyStoredValue(v.getContext(),"email");
                LocalStorage.storeUserRatings(v.getContext(),userId,SustainabilityUserRating,AffordablenessUserRating,NutritionUserRating);

                Intent intent = new Intent(ThirdPreferencesActivity.this, DisplayProductsActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

}

