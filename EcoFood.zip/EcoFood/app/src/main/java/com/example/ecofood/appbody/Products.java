package com.example.ecofood.appbody;

import com.example.ecofood.R;

import java.util.ArrayList;
import java.util.List;

public class Products {

    public static Products products;
    public static List<Product> productsList = new ArrayList<>();

    public Products getInstance() {
        return new Products();
    }

    public List<Product> getProducts(){
        if (productsList.size() > 0) productsList.clear(); // clear stack

        productsList.add(new Product("potatoes", "Vegetable", "yes", "no", "yes", "yes", 2, 1, "2", "280", R.drawable.potatoes));
        productsList.add(new Product("onions", "Vegetable", "no", "yes", "yes", "no", 2, 1, "2", "168", R.drawable.onions));
        productsList.add(new Product("banana", "Fruit", "no", "yes", "yes", "no", 2, 3, "1.5", "156", R.drawable.banana));
        productsList.add(new Product("bagel", "Wheat", "no", "yes", "yes", "no", 3, 3, "2.5", "103", R.drawable.bagel));
        productsList.add(new Product("sunflowerseeds", "Seed", "yes", "no", "yes", "yes", 2, 3, "3", "101", R.drawable.sunflowerseeds));
        productsList.add(new Product("bread", "Wheat", "no", "yes", "yes", "no", 1, 3, "1", "97", R.drawable.bread));
        productsList.add(new Product("olives", "Fruit", "no", "yes", "yes", "no", 2, 2, "1", "97", R.drawable.olives));
        productsList.add(new Product("rice", "Wheat", "yes", "no", "yes", "yes", 2, 3, "3", "88", R.drawable.rice));
        productsList.add(new Product("almonds", "Nut", "no", "yes", "yes", "no", 2, 3, "1.5", "69", R.drawable.almonds));
        return productsList;
    }
}
