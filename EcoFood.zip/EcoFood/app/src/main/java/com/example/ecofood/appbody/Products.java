package com.example.ecofood.appbody;

import com.example.ecofood.R;

import java.util.ArrayList;
import java.util.List;

public class Products {

    public static Products products;
    public static List<Product> productsList = new ArrayList<>();

    public Products getInstance() {
        return new Products();
    }

    public List<Product> getProducts(){
        if (productsList.size() > 0) productsList.clear(); // clear stack

        String imageUrl = "https://www.google.com/search?q=Andechser+Molkerei+Scheitz+GmbH+image&sxsrf=ALeKk03uvCFFJqOFwdt6noA0iTphV8-DOg:1587832366446&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjawqjBgITpAhWoxzgGHbkBDGYQ_AUoA3oECAsQBQ&biw=1232&bih=553#imgrc=n6CylD3m4WDwsM";

        //add product like this:
        //productsList.add(new Product(String productName, int Sustainability, int Affordableness, int Nutrition, String price, String ecoScore));
        return productsList;
    }
}
