package com.example.ecofood.webservice;

public class EmployeeModel {

    private String id;
    private String employee_name;
    private String employee_salary;
    private String employee_age;
    private String profile_image;

}
