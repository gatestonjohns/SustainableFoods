package com.example.ecofood.appbody;

public class Product {

    private String productName;
    private int Sustainability;
    private int	Affordableness;
    private int	Nutrition;
    private String price;
    private String ecoScore;

    public Product(String productName, int Sustainability, int Affordableness, int Nutrition, String price, String ecoScore) {
        this.productName = productName;
        this.Sustainability = Sustainability;
        this.Affordableness = Affordableness;
        this.Nutrition = Nutrition;
        this.price = price;
        this.ecoScore = ecoScore;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getSustainability() { return Sustainability; }

    public void setSustainability(int Sustainability) {
        this.Sustainability = Sustainability;
    }

    public int getAffordableness() { return Affordableness; }

    public void setAffordableness(int Affordableness) { this.Affordableness = Affordableness;}

    public int getNutrition() { return Nutrition; }

    public void setNutrition(int Nutrition) { this.Nutrition = Nutrition;}

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getEcoScore() {
        return ecoScore;
    }

    public void setEcoScore(String ecoScore) {
        this.ecoScore = ecoScore;
    }

}
