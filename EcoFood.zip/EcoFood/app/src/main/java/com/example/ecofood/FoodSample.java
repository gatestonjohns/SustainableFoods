package com.example.ecofood;

public class FoodSample {
    private String Entity;
    private double Emissions_per_1000_kilocalories;
    private double Land_use_per_1000_kilocalories;
    private double Water_withdrawals_per_1000_kilocalories;
    private double USD_for_1lb;
    private int Fat;
    private int Protein;
    private int Fiber;
    private int Carbs;
    private double Price_Normalized;

    public String getEntity() {
        return Entity;
    }

    public void setEntity(String entity) {
        Entity = entity;
    }

    public double getEmissions_per_1000_kilocalories() {
        return Emissions_per_1000_kilocalories;
    }

    public void setEmissions_per_1000_kilocalories(double emissions_per_1000_kilocalories) {
        Emissions_per_1000_kilocalories = emissions_per_1000_kilocalories;
    }

    public double getLand_use_per_1000_kilocalories() {
        return Land_use_per_1000_kilocalories;
    }

    public void setLand_use_per_1000_kilocalories(double land_use_per_1000_kilocalories) {
        Land_use_per_1000_kilocalories = land_use_per_1000_kilocalories;
    }

    public double getWater_withdrawals_per_1000_kilocalories() {
        return Water_withdrawals_per_1000_kilocalories;
    }

    public void setWater_withdrawals_per_1000_kilocalories(double water_withdrawals_per_1000_kilocalories) {
        Water_withdrawals_per_1000_kilocalories = water_withdrawals_per_1000_kilocalories;
    }

    public double getUSD_for_1lb() {
        return USD_for_1lb;
    }

    public void setUSD_for_1lb(double USD_for_1lb) {
        this.USD_for_1lb = USD_for_1lb;
    }

    public int getFat() {
        return Fat;
    }

    public void setFat(int fat) {
        Fat = fat;
    }

    public int getProtein() {
        return Protein;
    }

    public void setProtein(int protein) {
        Protein = protein;
    }

    public int getFiber() {
        return Fiber;
    }

    public void setFiber(int fiber) {
        Fiber = fiber;
    }

    public int getCarbs() {
        return Carbs;
    }

    public void setCarbs(int carbs) {
        Carbs = carbs;
    }

    public double getPrice_Normalized() {
        return Price_Normalized;
    }

    public void setPrice_Normalized(double price_Normalized) {
        Price_Normalized = price_Normalized;
    }
}
