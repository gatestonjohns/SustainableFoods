package com.example.ecofood;

public class FoodNames {

    private String foodName;

    public FoodNames(String animalName) {
        this.foodName = animalName;
    }

    public String getFoodName() {
        return this.foodName;
    }



}
