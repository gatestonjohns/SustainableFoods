package com.example.ecofood.appbody.preference;

import androidx.annotation.Nullable;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.example.ecofood.R;
import com.example.ecofood.utils.LocalStorage;

public class FirstPreferenceFragment extends Fragment implements View.OnClickListener {

    //@button_continuepreference is to continue to the next screen
    // private Button button_continuepreference;

    private FrameLayout framelayout_prefernce;
    private String TAG = "ButtonWorking";
    private View view;
    LinearLayout button_continuepreference;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.activity_app_body_navigation_preference_fragment, container, false);

        framelayout_prefernce = view.findViewById(R.id.framelayout_prefernce);
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        button_continuepreference = view.findViewById(R.id.button_continuepreference);
        button_continuepreference.setOnClickListener(this::onClick);
    }

    @Override
    public void onClick(View v) {


        switch (v.getId()) {

            case R.id.button_continuepreference:
                String userId = LocalStorage.getLocallyStoredValue(getActivity(),"email");
                Intent it = new Intent(getActivity(), ThirdPreferencesActivity.class);
                getActivity().startActivity(it);
                break;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        if (view != null){
            view.setWillNotDraw(false);
            view.invalidate();
            System.out.println("---> invalidate in fragment");
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        System.out.println("---> pause in fragment");
    }

    @Override
    public void onStop() {
        super.onStop();
        System.out.println("---> stop in fragment");
    }

    @Override
    public void onResume() {
        super.onResume();
        System.out.println("---> resume in fragment");
    }
}
