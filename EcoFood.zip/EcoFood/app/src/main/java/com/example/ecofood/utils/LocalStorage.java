package com.example.ecofood.utils;

import android.content.Context;
import android.content.SharedPreferences;


public class LocalStorage {

    private static final String sharedName = "YOUCARE_PREFERENCES";
    private SharedPreferences sharedPreferences;
    private static LocalStorage localStorage;


    /***
     * Created Singleton Class for accessing this class methods
     * @param context
     * @return
     */
    public static LocalStorage localStorage(Context context) {
        if (localStorage == null)
            localStorage = new LocalStorage();
        return localStorage;
    }

    // save String Preferences
    public static void saveToLocalStorage(Context mContext, String key, String value) {
        SharedPreferences mySharedPreferences = mContext.getSharedPreferences(sharedName, mContext.MODE_PRIVATE);
        SharedPreferences.Editor editor = mySharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    // load String Preferences
    public static String getLocallyStoredValue(Context mContext, String key) {
        SharedPreferences mySharedPreferences = mContext.getSharedPreferences(sharedName, mContext.MODE_PRIVATE);
        String credential = mySharedPreferences.getString(key, null);
        return credential;
    }

    public static int getLocallyStoredRating(Context mContext, String key) {
        SharedPreferences mySharedPreferences = mContext.getSharedPreferences(sharedName, mContext.MODE_PRIVATE);
        int rating = mySharedPreferences.getInt(key, 0);
        return rating;
    }

    //Remove String Preference
    public static void removePreferences(Context mContext, String key) {
        SharedPreferences mySharedPreferences = mContext.getSharedPreferences(sharedName, mContext.MODE_PRIVATE);
        SharedPreferences.Editor editor = mySharedPreferences.edit();
        editor.remove(key);
        editor.commit();
    }

    public static void clearPreferences(Context mContext) {
        SharedPreferences mySharedPreferences = mContext.getSharedPreferences(sharedName, mContext.MODE_PRIVATE);
        SharedPreferences.Editor editor = mySharedPreferences.edit();
        editor.clear();
        editor.apply();
    }


    /***
     * STORING USER PREFERENCES TO SHARED PREFERENCES
     * @param mContext
     * @param userId
     */
    public static void storeUserPrefernces(Context mContext,String userId, String isVegan,String isVegetarian,String isGluten,String isLakto,String noRestricitons){
        SharedPreferences mySharedPreferences = mContext.getSharedPreferences(sharedName, mContext.MODE_PRIVATE);
        SharedPreferences.Editor editor = mySharedPreferences.edit();
        editor.putString(Constants.userId, userId);
        editor.commit();
    }


    /***
     * STORING USER RATINGS TO SHARED PREFERENCES
     * @param context
     * @param userId
     * @param SustainabilityRating
     * @param AffordablenessRating
     * @param NutritionRating
     */
    public static void storeUserRatings(Context context, String userId, int SustainabilityRating, int AffordablenessRating, int NutritionRating){
        SharedPreferences mySharedPreferences = context.getSharedPreferences(sharedName, context.MODE_PRIVATE);
        SharedPreferences.Editor editor = mySharedPreferences.edit();
        editor.putString(Constants.userId, userId);
        editor.putInt(Constants.Sustainabilityrating, SustainabilityRating);
        editor.putInt(Constants.Affordablenessrating, AffordablenessRating);
        editor.putInt(Constants.Nutritionrating, NutritionRating);
        editor.commit();
    }


    public static void removeUserPreferences(Context context){
        SharedPreferences mySharedPreferences = context.getSharedPreferences(sharedName, context.MODE_PRIVATE);
        SharedPreferences.Editor editor = mySharedPreferences.edit();
        editor.remove(Constants.Sustainabilityrating);
        editor.remove(Constants.Affordablenessrating);
        editor.remove(Constants.Nutritionrating);
        editor.commit();
    }

}
