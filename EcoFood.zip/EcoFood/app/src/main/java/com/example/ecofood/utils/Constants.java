package com.example.ecofood.utils;

public class Constants {
    // App Constants
    public static final String userId = "USER_ID";
    public static final String Sustainabilityrating = "SUSTAINABILITY";
    public static final String Affordablenessrating = "AFFORDABLENESS";
    public static final String Nutritionrating = "NUTRITION";
}
