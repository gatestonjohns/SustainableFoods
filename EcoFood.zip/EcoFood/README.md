# Android-Food-Application
Android mobile application "Your Choice"  prototype suggesting sustainable product alternatives based on consumer preference.

## Screenshots from the applicaiton
|<img src="ScreenShots/Screenshot_20200713-175334.png" width="150" height="250" >  <img src="ScreenShots/Screenshot_20200713-175346.png" width="150" height="250" >
<img src="ScreenShots/Screenshot_20200713-175421.png" width="150" height="250" > <img src="ScreenShots/Screenshot_20200713-175432.png" width="150" height="250" >
<img src="ScreenShots/Screenshot_20200713-175537.png" width="150" height="250" > <img src="ScreenShots/Screenshot_20200713-175544.png" width="150" height="250" >|
